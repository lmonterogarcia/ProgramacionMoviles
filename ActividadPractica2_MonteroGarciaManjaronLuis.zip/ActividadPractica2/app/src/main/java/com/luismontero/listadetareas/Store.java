package com.luismontero.listadetareas;

import java.util.ArrayList;
import java.util.List;

public class Store {

    public static List<Tarea> lstTareas = new ArrayList<Tarea>();
    public static int tareaSeleccionada;
    public static int ultimoId;
    public static boolean booInsertar;
}
